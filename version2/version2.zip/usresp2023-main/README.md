This project is continuation of https://github.com/GitData-GA/iasc2023.

We made a few changes:

- Update the dataset to the end of March, 2023

- Create a new model, which is a combination of ridge and lasso regularization

- Update the visualizations and results

- Write a new report in PDF
