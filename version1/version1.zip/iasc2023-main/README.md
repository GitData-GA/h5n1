# 2022 - 2023 H5N1 Bird Flu Modeling and Prediction in the United States

<img src="https://h5n1.gd.edu.kg/images/bg-1.jpg" width=400px />

- [Basic Information](#basic-information)
  * [Authors](#authors)
  * [Objective](#objective)
  * [Project Website](#project-website)
  * [Project Poster](#project-poster)
  * [Project Dashboard](#project-dashboard)
- [Technical Information](#technical-information)
  * [Tools Used](#tools-used)
  * [Original Code](#original-code)
  * [Dataset Location](#dataset-location)
- [Read Our Analysis Report](#read-our-analysis-report)
  * [Read Online](#read-online)
  * [Read as PDF](#read-as-pdf)
- [Source Data](#source-data)

# Basic Information

## Authors

**Author 1:**

Name: Weilin Cheng

Current Institution: University of California, Davis

School email: <img src="https://www.gd.edu.kg/images/emails/wncheng.png"/>

GitData email: wcheng@gd.edu.kg

**Author 2:**

Name: Hengyuan Liu

Current Institution: University of California, Davis

School email: <img src="https://www.gd.edu.kg/images/emails/hyliu.png"/>

GitData email: hliu@gd.edu.kg

**Author 3:**

Name: Kathy Mo

Current Institution: University of California, Davis

School email: <img src="https://www.gd.edu.kg/images/emails/kamo.png"/>

GitData email: kmo@gd.edu.kg

**Author 4:**

Name: Sida Tian

Current Institution: University of Michigan, Ann Arbor

School email: <img src="https://www.gd.edu.kg/images/emails/startian.png"/>

GitData email: stain@gd.edu.kg

**Author 5:**

Name: Li Yuan

Current Institution: University of Michigan, Ann Arbor

School email: <img src="https://www.gd.edu.kg/images/emails/leeyuan.png"/>

GitData email: lyuan@gd.edu.kg

## Objective

The objective of this report is to develop and evaluate machine learning models to predict the outbreak of the H5N1 virus in the United States in the future. Our report will focus on analyzing data from past outbreaks to build models that can accurately predict the likelihood of future outbreaks in different regions of the country. By identifying high-risk areas and providing actionable insights, we hope to contribute to efforts to mitigate the impact of the H5N1 virus and protect public health.

## Project Website

The following is the website for this project. Feel free to share with the link.

https://h5n1.gd.edu.kg/

## Project Poster

<img src="https://iasc2023.gd.edu.kg/poster/iasc2023-poster.jpg" width=400px />

https://pdfviewer.gd.edu.kg/web/viewer?file=https://iasc2023.gd.edu.kg/poster/iasc2023-poster.pdf

OR 

https://github.com/GitData-GA/iasc2023/tree/main/poster

## Project Dashboard

https://iasc2023.gd.edu.kg/dashboard/

# Technical Information

## Tools Used

1. R Studio (RStudio 2022.12.0+353 "Elsbeth Geranium" Release (7d165dcfc1b6d300eb247738db2c7076234f6ef0, 2022-12-03) for Windows
Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) RStudio/2022.12.0+353 Chrome/102.0.5005.167 Electron/19.1.3 Safari/537.36)

- library(dplyr), library(ggplot2), library(tidyr), library(usmap), library(ggpubr), library(grid), library(gridExtra), library(patchwork), library(sf), library(knitr), library("imputeTS"), library(textstem), library(GGally), library(pROC), library(lmtest), library(car), library(glmnet), library(psych))

2. R (Version 4.2.2)

3. GitHub

- For source control

4. Cloudflare

- For DNS management and file hosting

## Original Code

Download the following R Markdown file to generate the full PDF and HTML reports.

https://github.com/GitData-GA/iasc2023/blob/main/code/2022%20-%202023%20H5N1%20Bird%20Flu%20Modeling%20and%20Prediction%20in%20the%20United%20States.Rmd

Download the following R script to see the data cleaning process (read the comments at the top of the script for more information)

https://github.com/GitData-GA/iasc2023/blob/main/code/Data_Cleaning.R

## Dataset Location

https://github.com/GitData-GA/iasc2023/tree/main/dataset

# Read Our Analysis Report

## Read Online

https://iasc2023.gd.edu.kg/report/

## Read as PDF

https://pdfviewer.gd.edu.kg/web/viewer?file=https://iasc2023.gd.edu.kg/report/2022%20-%202023%20H5N1%20Bird%20Flu%20Modeling%20and%20Prediction%20in%20the%20United%20States.pdf

# Source Data

1. United States Counties Database: https://simplemaps.com/data/us-counties

3. H5N1 Bird Flu Detections across the United States (Backyard and Commercial): https://www.cdc.gov/flu/avianflu/data-map-commercial.html

5. H5N1 Bird Flu Detections across the United States (Wild Birds): https://www.cdc.gov/flu/avianflu/data-map-wild-birds.html

7. Monthly Average Temperature of each County across the United States: https://www.ncei.noaa.gov/access/monitoring/climate-at-a-glance/county/mapping

9. Monthly Average Temperature of each County in Hawaii: https://weatherspark.com/map?id=145043

Copyright 2023 GitData
